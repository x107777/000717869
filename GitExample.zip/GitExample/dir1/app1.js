// JavaScript Document
console.log(123);