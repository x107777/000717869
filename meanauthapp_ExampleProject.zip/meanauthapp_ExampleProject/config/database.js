//database
module.exports = {
    database: 'mongodb://0.0.0.0:27017/mylife',
    secret: 'yoursecret'
}