//imports
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  //variables
  user: Object;
  //--------------------------------------------NEW------------------------------------------------------------------------------------
  username: String;
  email: String;
  //--------------------------------------------NEW END------------------------------------------------------------------------------------

  constructor(
    private authService: AuthService,
    private router: Router,
    private flashMessage: FlashMessagesService
  ) { }

  //on default shows current user(username and email))
  ngOnInit() {
    this.authService.getProfile().subscribe(profile => {
      this.user = profile.user;
    },
    err => {
      console.log(err);
      return false;
    });
  }

  //--------------------------------------------NEW------------------------------------------------------------------------------------

  //to change profile
  onChange() {

    const user = {
      username: this.username, //new username
      email: this.email //new email
    }  

      this.authService.updateProfile(user).subscribe(data => { //to bring it to the server via authService
        if(data.success) { //if profile updated successfully
          this.flashMessage.show('Profile updated', {
            cssClass: 'alert-success', timeout: 5000});
            this.ngOnInit();
          this.router.navigate(['profile']);
        } else { //if profile not updated successfully
          this.flashMessage.show('Error in updating profile', {
            cssClass: 'alert-danger', timeout: 5000});
          this.router.navigate(['profile']);
        }
      });
//--------------------------------------------NEW END ------------------------------------------------------------------------------------

  }
}
