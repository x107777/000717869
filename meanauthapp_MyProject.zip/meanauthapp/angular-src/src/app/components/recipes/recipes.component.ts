//--------------------------------------------NEW------------------------------------------------------------------------------------

//imports
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';


@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})

export class RecipesComponent {
 
  //variables
  muffins:string = 'assets/images/muffins.jpg';
  user: Object;
  recipes: String;
  
  constructor(
    private authService:AuthService,
    private router: Router,
    private flashMessage: FlashMessagesService
  ) { }

  //on default shows current recipes of user
  ngOnInit() {
    this.authService.getProfile().subscribe(recipes => {
      this.user = recipes.user;
    },
    err => {
      console.log(err);
      return false;
    });
  }


  //to save new recipes/update
  onRecipeChange() {

    const user = {
      recipes: this.recipes //new recipes text
    }
    console.log(this.recipes);    
   
      this.authService.recipeChange(user).subscribe(data => { //to bring it to the server via authService
        if(data.success) { //if recipes text updated successfully
          this.flashMessage.show('New Recipe saved', {
            cssClass: 'alert-success', timeout: 5000});
            this.ngOnInit();
          this.router.navigate(['recipes']);
        } else { //if recipes text not updated successfully
          this.flashMessage.show('Error in saving new Recipe', {
            cssClass: 'alert-danger', timeout: 5000});
          this.router.navigate(['recipes']);
        }
      });

  }

}

//--------------------------------------------NEW END------------------------------------------------------------------------------------


