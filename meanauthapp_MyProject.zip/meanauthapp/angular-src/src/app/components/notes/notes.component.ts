//--------------------------------------------NEW------------------------------------------------------------------------------------

//imports
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {

 //variables
  user: Object;
  notes: String;
  
  constructor(
    private authService:AuthService,
    private router: Router,
    private flashMessage: FlashMessagesService
  ) { }

  //on default shows current notes of user
  ngOnInit() {
    this.authService.getProfile().subscribe(notes => {
      this.user = notes.user;
    },
    err => {
      console.log(err);
      return false;
    });
  }

  //to save new notes/update
  onNewNotesSubmit() {

    const user = {
      notes: this.notes //new notes
    }
    console.log(this.notes);    
   
      this.authService.newNotes(user).subscribe(data => { //to bring it to the server via authService
        if(data.success) { //if notes updated successfully
          this.flashMessage.show('New Note saved', {
            cssClass: 'alert-success', timeout: 5000});
            this.ngOnInit();
          this.router.navigate(['notes']);
        } else { //if notes not updated successfully
          this.flashMessage.show('Error in saving new Note', {
            cssClass: 'alert-danger', timeout: 5000});
          this.router.navigate(['notes']);
        }
      });

  }

  //to delete notes
  onDone() {
    const user = {
      notes: '' //new note is empty string
    }
    
      this.authService.newNotes(user).subscribe(data => { //to bring it to the server via authService
        if(data.success) { //if notes updated successfully
          this.flashMessage.show('Done', {
            cssClass: 'alert-success', timeout: 5000});
            this.ngOnInit();
          this.router.navigate(['notes']);
        } else { //if notes not updated successfully
          this.flashMessage.show('Error', {
            cssClass: 'alert-danger', timeout: 5000});
          this.router.navigate(['notes']);
        }
      });

  }

}

//--------------------------------------------NEW END------------------------------------------------------------------------------------

