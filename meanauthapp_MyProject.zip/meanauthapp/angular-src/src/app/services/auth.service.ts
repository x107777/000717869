//imports
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import {tokenNotExpired} from 'angular2-jwt'

@Injectable()
export class AuthService {

  authToken: any;
  name: any;
  user: any;
  
  constructor(private http: Http) { }

  //connection to server via post request to route register, consisting of JSON webtoken (sigiture, payload and headers)
  registerUser(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/users/register', user, {headers: headers}) //local running
    //return this.http.post('users/register', user, {headers: headers})
      .map(res => res.json());
  }

  //connection to server via post request to route authenticate
  authenticateUser(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:3000/users/authenticate', user, {headers: headers}) //local running
    //return this.http.post('users/authenticate', user, {headers: headers})
      .map(res => res.json());
      
  }

  //connection to server via get request to route profile
  getProfile() {
    let headers = new Headers();
    this.loadToken();
    headers.append('Authorization', this.authToken);
    headers.append('Content-Type', 'application/json');
    return this.http.get('http://localhost:3000/users/profile', {headers: headers})
    //return this.http.get('users/profile', {headers: headers})
      .map(res => res.json());
  }

//--------------------------------------------NEW------------------------------------------------------------------------------------

  //connection to server via put request to route updateNotes
  newNotes(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.put('http://localhost:3000/users/updateNotes', user, {headers: headers})
    //return this.http.put('users/updateNotes', user, {headers: headers})
    .map(res => res.json());
  }

  //connection to server via put request to route updateProfile
  updateProfile(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.put('http://localhost:3000/users/updateProfile', user, {headers: headers})
    //return this.http.put('users/updateProfile', user, {headers: headers})
    .map(res => res.json());
  }

  //connection to server via put request to route updateRecipes
  recipeChange(user) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.put('http://localhost:3000/users/updateRecipes', user, {headers: headers})
    //return this.http.put('users/updateRecipes', user, {headers: headers})
    .map(res => res.json());
  }

//--------------------------------------------NEW END------------------------------------------------------------------------------------

  //store user in local storage 
  storeUserData(token, user) {
    localStorage.setItem('id_token', token);
    localStorage.setItem('user', JSON.stringify(user));
    this.authToken = token;
    this.user = user;
  }

  //load token from local storage 
  loadToken() {
    const token = localStorage.getItem('id_token');
    this.authToken = token;
    //return token;
  }

  //logged in if token is not expired
  loggedIn() {
    return tokenNotExpired("id_token");
  }

  //logout
  logout() { 
    this.authToken = null;
    this.user = null;
    localStorage.clear();
  }
}
